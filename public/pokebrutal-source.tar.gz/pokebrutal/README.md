# POKÉBRUTAL

> 新粗野主义宝可梦图鉴 · 一个用来学 `shadcn` + `TanStack Start` + `neobrutalism` 的小项目

**POKÉBRUTAL** = POKÉ(mon) + (neo)**BRUTAL**ism

一个能跑、能学、能抄的练手项目：用 **TanStack Start** 做全栈框架，用 **shadcn Registry 协议** 接入
**neobrutalism.com** 的 21 个新粗野主义组件，用 **PokeAPI** 喂真实数据。

---

## 这个项目能学到什么

| 主题 | 在本项目里对应什么 |
|---|---|
| **CLI 工具** | `shadcn init` / `add` / `--dry-run` / `--overwrite` / `--diff` / `view` / `search` 全部真实跑过 |
| **Registry 协议** | 把 `neobrutalism.com` 注册成 `@neobrutalism-base` 命名空间，一条命令装 21 个组件 |
| **项目规范** | Tailwind v4、CSS 变量体系、`@/*` 路径别名、`components/ui` 目录约定、`components.json` 逐字段 |
| **设计系统** | 新粗野主义主题变量（零圆角 + 硬偏移阴影 + 粗黑边框），改 3 个变量全站变样 |
| **全栈框架** | TanStack Start 文件式路由、同构 loader（SSR）、`head()` 元信息、Nitro 构建产物 |

---

## 快速开始

```bash
pnpm install
pnpm dev                        # http://localhost:3000
pnpm build                      # 产物在 .output/，纯 Node 服务
node .output/server/index.mjs   # 起生产服务
```

> 本项目不需要任何 API Key —— PokeAPI 是公开免费接口。

---

## 页面一览

| 路由 | 页面 | 用到的组件 |
|---|---|---|
| `/` | 首页 Hero + 三大看点 + 精选六只 | Card / Badge / Button / Progress / Separator |
| `/dex` | 图鉴列表（168 只，本地搜索排序） | Input / Select / Switch / Checkbox / Badge / Card |
| `/dex/:id` | 详情页（**SSR loader 实时抓 PokeAPI**） | Tabs / Table / Alert / Accordion / Tooltip / Badge |
| `/matchup` | 属性克制计算器（18×18 双属性相乘） | Checkbox / Table / Badge / Card / Separator |
| `/lab` | 组件实验室（21 个组件实况 + 安装命令） | 全部 21 个 |
| `/guide` | 从零搭建手册（11 步） | Tabs / Card / Badge / Separator |

---

## 目录结构

```
pokebrutal/
├── components.json              # shadcn CLI 的项目说明书（含 registries 命名空间）
├── vite.config.ts               # nitro + tanstackStart + tailwindcss + react 四个插件
├── tsconfig.json                # 已内置 @/* 和 #/* 别名
├── scripts/
│   ├── fetch-zh-names.mjs       # 一次性脚本：抓 168 只宝可梦的官方中文名
│   └── fetch-dex.mjs            # 一次性脚本：抓图鉴快照（属性/种族值/身高体重）
└── src/
    ├── styles.css               # ★ 主题核心：neobrutalism CSS 变量 + 属性色板
    ├── router.tsx               # 路由器实例
    ├── components/
    │   ├── ui/                  # ★ 21 个 neobrutalism 组件（registry 拷贝而来，可随意改）
    │   ├── site-header.tsx      # 自写：导航 + 暗色模式切换
    │   └── type-badge.tsx       # 自写：属性徽章（复用 Badge 并注入属性色）
    ├── data/
    │   ├── dex.ts               # 生成的图鉴快照（168 条，勿手改）
    │   └── zh-names.ts          # 生成的中文名表（168 条，勿手改）
    ├── lib/
    │   ├── utils.ts             # cn() —— 所有组件都依赖它
    │   ├── type-chart.ts        # ★ 18×18 属性克制表 + 倍率计算
    │   └── pokeapi.ts           # PokeAPI 访问层 + 类型定义
    └── routes/
        ├── __root.tsx           # 全站 Layout（Header/Footer/字体/TooltipProvider）
        ├── index.tsx            # /
        ├── dex/index.tsx        # /dex      （文件式路由：目录即嵌套）
        ├── dex/$id.tsx          # /dex/:id  （loader 走 SSR）
        ├── matchup.tsx          # /matchup
        ├── lab.tsx              # /lab
        └── guide.tsx            # /guide
```

---

## 核心机制速览

### 1. 一切都是 CSS 变量

新粗野主义的全部观感来自 `src/styles.css`：

```css
:root {
  --radius: 0;                              /* 零圆角 */
  --border: #000;                           /* 纯黑边框 */
  --primary: #ffdc58;                       /* 高饱和主黄 */
}
@theme inline {
  --shadow-md: 4px 4px 0 0 var(--border);   /* 硬偏移阴影，无模糊 */
  --color-primary: var(--primary);          /* 暴露给 Tailwind 工具类 */
}
```

改这三行，21 个组件的观感一起变。

### 2. Registry 协议 = 拷源码，不是装依赖

`components.json` 里登记命名空间：

```json
{
  "registries": {
    "@neobrutalism": "https://neobrutalism.com/r/radix/{name}.json",
    "@neobrutalism-base": "https://neobrutalism.com/r/base/{name}.json"
  }
}
```

之后 `npx shadcn@latest add @neobrutalism-base/button` 会把 `button.tsx` **源码**写进
`src/components/ui/`。代码从此归你，可以随便改 —— 代价是上游更新要自己 `--diff` 跟进。

### 3. 两种数据策略

- **列表页**：168 条数据在构建期抓成静态 TS 模块 → 本地搜索/排序零延迟
- **详情页**：`loader` 在服务端实时请求 PokeAPI → SSR 出首屏 HTML，客户端跳转时同构重跑

---

## 详细文档

- [**从零搭建全流程**](docs/01-搭建全流程.md) —— 11 步复现指南，每步含命令 + 文件 + 原理
- [**踩坑与决策记录**](docs/02-踩坑与决策记录.md) —— 真实遇到的 6 个问题及处理
- [**shadcn / Registry 参考资料**](docs/03-shadcn-参考资料.md) —— CLI 参数表、registry schema、components.json 字段

---

## 技术栈版本

| 包 | 版本 |
|---|---|
| Node | 24.14.1 |
| pnpm | 10.33.0 |
| TanStack Start / Router | latest（2026-09） |
| Vite | 8.x |
| React | 19.2 |
| Tailwind CSS | 4.1 |
| shadcn CLI | 4.21.0 |
| neobrutalism registry | v2.3（含 54 个 item） |
| @base-ui/react | 1.8.0 |

---

数据来自 [PokeAPI](https://pokeapi.co)，组件来自 [neobrutalism.com](https://neobrutalism.com)，
文档参考 [shadcn 中文站](https://www.shadcn.com.cn)。
